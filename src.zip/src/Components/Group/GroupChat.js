import React from "react";

const GroupChat = () => {
  return <div>GroupChat</div>;
};

export default GroupChat;
